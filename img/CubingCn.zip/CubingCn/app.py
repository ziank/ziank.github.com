# -*- coding:utf-8 -*-
#authour:ziank

from cubing import app, db
from cubing.spider import CubingSpider
from datetime import datetime as dt

if __name__ == '__main__':
    db.create_all()
    print dt.now()
    spider = CubingSpider()
    spider.start()
    app.run(host="0.0.0.0", port=8888, debug=False)
    spider._stopFlag = True
    spider.join()
