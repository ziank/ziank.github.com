# -*- coding:utf-8 -*-
#authour:ziank
from flask import Flask
from flask.ext.sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config.from_object('cubing.fileconfig')
db = SQLAlchemy(app)


def debugPrint(args, *kwargs):
    if __debug__:
        print(args, kwargs)

import cubing.views