# -*- coding:utf-8 -*-
#authour:ziank
from cubing.models.competition import Competition
from cubing.models.user import User