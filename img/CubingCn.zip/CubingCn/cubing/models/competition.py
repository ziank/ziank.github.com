# -*- coding:utf-8 -*-
#authour:ziank

from cubing import db
from datetime import datetime

class Competition(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(256), unique=True)
    href = db.Column(db.String(256), unique=True)
    province = db.Column(db.String(32))
    city = db.Column(db.String(32))
    address = db.Column(db.String(512))
    isWCA = db.Column(db.Boolean)
    date = db.Column(db.Date)
    dateDuring = db.Column(db.String(128))

    def __init__(self, name, href, isWCA, date=datetime.now(), dateDuring='', province='', city='', address=''):
        self.name = name
        self.href = href
        self.isWCA = isWCA
        self.date = date
        self.dateDuring = dateDuring
        self.province = province
        self.city = city
        self.address = address

    def __repr__(self):
        return self.name

    def dicData(self):
        dic = {}
        dic["name"] = self.name#.encode("utf-8", "ignore")
        dic["id"] = self.id
        dic["href"] = self.href
        dic["province"] = self.province#.encode("utf-8", "ignore")
        dic["city"] = self.city#.encode("utf-8", "ignore")
        dic["address"] = self.address#.encode("utf-8", "ignore")
        dic["isWCA"] = self.isWCA
        dic["date"] = self.date.strftime("%y-%m-%d %H:%M:%S")
        dic["dateDuring"] = self.dateDuring
        return dic