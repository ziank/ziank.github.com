# -*- coding:utf-8 -*-
#authour:ziank
from cubing import db


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    #username = db.Column(db.String(80), unique=True)
    #password = db.Column(db.String(16))
    #email = db.Column(db.String(120), unique=True)
    deviceId = db.Column(db.String(120), unique=True)

    def __init__(self, deviceId):#username, email, passwd):
        #self.username = username
        #self.email = email
        #self.password = passwd
        self.deviceId = deviceId

    def __repr__(self):
        return '<User %r>' % self.deviceId