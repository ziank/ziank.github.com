# -*- coding:utf-8 -*-
#authour:ziank
from bs4 import BeautifulSoup
from cubing.models import Competition

class CubingExtractor:
    def parseCompetitionList(self, content):
        soup = BeautifulSoup(content, "html.parser")
        tbody = soup.find('tbody')
        if tbody:
            comlist = tbody.findAll('tr')
            competitionList = []
            for com in comlist:
                tdList = com.findAll('td')
                if tdList:
                    dateDuring = tdList[0].text
                    href = tdList[1].find('a').attrs['href']
                    img = tdList[1].find('img')
                    if img and 'wca-competition' in img.get('class'):
                        isWCA = True
                    else:
                        isWCA = False
                    name = tdList[1].find('a').text
                    province = tdList[2].text
                    city = tdList[3].text
                    address = tdList[4].text
                    comp = Competition(name, href, isWCA, dateDuring=dateDuring, province=province, city=city, address=address)
                    competitionList.append(comp)