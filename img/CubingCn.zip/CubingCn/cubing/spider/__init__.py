# -*- coding:utf-8 -*-
#authour:ziank

from cubing.spider.cubingspider import CubingSpider