# -*- coding:utf-8 -*-
#authour:ziank
import urllib2
import os
from threading import Thread
from datetime import datetime as dt
import time
from bs4 import BeautifulSoup
from cubing.models import *
from cubing import db, debugPrint
from cubing.pushservice.apns import APNs, Frame, Payload

class CubingSpider(Thread):
    #成员变量
    _opener = None
    _stopFlag = False
    _competitionUrl = 'http://cubingchina.com/competition'

    def __init__(self):
        Thread.__init__(self)
        self._opener = urllib2.build_opener()

    def run(self):
        self.crawl()
        while not self._stopFlag:
            now_time = dt.now()
            if now_time.minute == 0:
                try:
                    self.crawl()
                except:
                    pass
            else :
                time.sleep(10)

    #抓取网页
    def crawl(self):
        debugPrint("start crawl")
        response = self._opener.open(self._competitionUrl)
        content = response.read().decode('utf-8')
        try:
            self.parseCompetitionList(content)
        except:
            pass

    def parseCompetitionList(self, content):
        soup = BeautifulSoup(content, "html.parser")
        tbody = soup.find('tbody')
        if tbody:
            comlist = tbody.findAll('tr')
            newCompList = []
            for com in comlist:
                tdList = com.findAll('td')
                if tdList:
                    dateDuring = tdList[0].text
                    href = tdList[1].find('a').attrs['href']
                    img = tdList[1].find('img')
                    if img and 'wca-competition' in img.get('class'):
                        isWCA = True
                    else:
                        isWCA = False
                    name = tdList[1].find('a').text
                    province = tdList[2].text
                    city = tdList[3].text
                    address = tdList[4].text
                    if len(Competition.query.filter_by(href=href).all()) == 0:
                        try:
                            comp = Competition(name, href, isWCA, dateDuring=dateDuring, province=province, city=city, address=address)
                            db.session.add(comp)
                            newCompList.append(comp)
                        except:
                            pass

            # if __debug__ and len(newCompList) == 0:
            #     newCompList.append(Competition("test", None, None, None))

            if len(newCompList) > 0:
                try:
                    db.session.commit()
                except Exception, e:
                    print(e)
                try:
                    self.pushApns(newCompList)
                except Exception, e:
                    print(e)

    def pushApns(self, pushList):
        frame = Frame()
        identifier = 1
        expiry = time.time() + 3600
        priority = 10
        shouldSend = False
        for comp in pushList:
            payload = Payload(alert=("有新的比赛发布:" + comp.name).decode("utf-8", "ignore"), sound="default", badge=1)
            for user in User.query.all():
                if user.deviceId and user.deviceId != '':
                    deviceToken = user.deviceId[1:-1].replace(" ", "")
                    frame.add_item(deviceToken, payload, identifier, expiry, priority)
                    shouldSend = True
        if shouldSend:
            apns = APNs(use_sandbox=True, cert_file='pushcert/cer.pem', key_file='pushcert/key.pem', enhanced=True)
            apns.gateway_server.send_notification_multiple(frame)

            apns = APNs(use_sandbox=False, cert_file='pushcert/cer.pem', key_file='pushcert/key.pem', enhanced=True)
            apns.gateway_server.send_notification_multiple(frame)

if __name__ == '__main__':
    spider = CubingSpider()
    spider.crawl()