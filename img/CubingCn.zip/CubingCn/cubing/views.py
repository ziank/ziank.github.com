# -*- coding:utf-8 -*-
#authour:ziank
from flask import *
from cubing import app, db
from cubing.models import *

@app.route('/')
@app.route('/index')
def index():
    compList = Competition.query.all()
    resultList = []

    for comp in compList:
        resultList.append(comp.dicData())

    return jsonify(values = resultList, ensure_ascii=False)

@app.route('/registerDevice', methods=['POST'])
def registerDevice():
    deviceId = request.form.get('deviceToken')
    if len(User.query.filter_by(deviceId=deviceId).all()) == 0:
        user = User(deviceId)
        db.session.add(user)
        db.session.commit()
    return jsonify({"success":1})

@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('userName')
    password = request.form.get('password')
    email = request.form.get('email')
    deviceId = request.form.get('deviceId')
    user = User(username=username, passwd=password, email=email)
    user.deviceId = deviceId
    db.session.add(user)
    db.session.commit()
    return jsonify({'success':1})

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('userName')
    password = request.form.get('password')
    deviceId = request.form.get('deviceId')
    filterUsers = User.query.filter('userName=%s' % username).all()
    if len(filterUsers) != 0:
        user = filterUsers[0]
        if user.password == password:
            if user.deviceId != deviceId:
                user.deviceId = deviceId
                db.session.update(user)
                db.session.commit()
            return jsonify({'success':1})

    return jsonify({'success':0})
